package com.ashsoftware.petsearch.petseach;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ashsoftware.petsearch.petseach.utils.ApiConfig;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private List<MDMovie> mDataset;
    private  Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView lang, tv_heading, tv_Desc, date;
        public ImageView iv_thumb;

        public MyViewHolder(View v) {
            super(v);
            lang = (TextView) v.findViewById(R.id.lang);
            tv_heading = (TextView) v.findViewById(R.id.tv_heading);
            tv_Desc = (TextView) v.findViewById(R.id.tv_Desc);
            date = (TextView) v.findViewById(R.id.date);
            iv_thumb = (ImageView) v.findViewById(R.id.iv_thumb);




        }
    }


    public MyAdapter(List<MDMovie> moviesList,Context context) {
        this.mDataset = moviesList;
        this.context=context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.my_movie_list_view, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        MDMovie movie = mDataset.get(position);
        //holder.iv_thumb.set(mDataset.get(position).getName());
        Glide.with(context).load(ApiConfig.IMAG_URI+mDataset.get(position).getPoster_path()).into(holder.iv_thumb);
        holder.lang.setText(mDataset.get(position).getOriginal_language());
        holder.date.setText(mDataset.get(position).getRelease_date());
        holder.tv_Desc.setText(mDataset.get(position).getOverview());
        holder.tv_heading.setText(mDataset.get(position).getTitle());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,MovieDetails.class);
                intent.putExtra("id",String.valueOf(mDataset.get(position).getId()));
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}
