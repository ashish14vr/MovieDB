package com.ashsoftware.petsearch.petseach;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.ashsoftware.petsearch.petseach.utils.ApiConfig;
import com.ashsoftware.petsearch.petseach.utils.App;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MovieDetails extends AppCompatActivity {
    private TextView desc;
    private ImageView moviePoster;
    Toolbar toolbar;
    private TextView tv_duration,date,rating,budget,revenue, tv_lang,category_name;

    private static String I_D = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_movie_details );


        toolbar=(Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        setTitle("");

        moviePoster = (ImageView) findViewById(R.id.iv_thumb);
        desc = (TextView) findViewById(R.id.tv_des);
        tv_duration = (TextView) findViewById(R.id.tv_duration);
        date = (TextView) findViewById(R.id.date);
        rating = (TextView) findViewById(R.id.rating);

        budget = (TextView) findViewById(R.id.budget);
        revenue = (TextView) findViewById(R.id.revenue);
        tv_lang = (TextView )findViewById(R.id.tv_lang);
        category_name = (TextView) findViewById(R.id.category_name);




       I_D =  getIntent().getExtras().getString("id",null);
       if (I_D != null )
       getMovieDetails();
    }

    private void getMovieDetails(){

        StringRequest strReq = new StringRequest(Request.Method.GET,
                ApiConfig.MOVIE_DETAILS + I_D + ApiConfig.API_KEY_LNG, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {

                try {

                    JSONObject jObj = new JSONObject(response);
                    Gson gson = new Gson();
                    Movie movie = gson.fromJson(jObj.toString(),Movie.class);
                    desc.setText(movie.getOverview());
                    Glide.with(getBaseContext()).load(ApiConfig.IMAG_ORIGINAL+movie.getBackdrop_path()).into(moviePoster);
                    //tv_duration.setText(movie.get);
                    rating.setText(String.valueOf(movie.getVote_average()));
                    date.setText(movie.getRelease_date());
                    revenue.setText(String.valueOf(movie.getRevenue()));
                    budget.setText(String.valueOf(movie.getBudget()));
                    tv_lang.setText(movie.getOriginal_language());
                    String genr="";
                    JSONArray array = jObj.getJSONArray("genres");
                    for (int i=0; i < jObj.getJSONArray("genres").length();i++){
                        String strname = array.getJSONObject(i).getString("name");
                        genr += strname+",";
                    }
                    category_name.setText(genr.substring(0,genr.length()-1));
                    setTitle(movie.getOriginal_title());
                } catch (JSONException e) {
                    e.printStackTrace();

                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


            }
        });

        strReq.setShouldCache(false);
        App.getInstance().addToRequestQueue(strReq);
        strReq.setRetryPolicy(new DefaultRetryPolicy(
                500000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId()==android.R.id.home){
            finish();
        }
        return true;

    }

    @Override
    protected void onResume() {
        super.onResume();

    }
}
