package com.ashsoftware.petsearch.petseach;

import java.io.Serializable;

class MDMovie implements Serializable {

    private String Name;
    private String ID;
    private String Description;
    private String Thumbnail;
    private int id;
    private float vote_average;
    private String title,poster_path,original_language,backdrop_path,overview,release_date;
/*"vote_count": 1897,
	"id": 335983,
	"video": false,
	"vote_average": 6.6,
	"title": "Venom",
	"popularity": 354.542,
	"poster_path": "\/2uNW4WbgBXL25BAbXGLnLqX71Sw.jpg",
	"original_language": "en",
	"original_title": "Venom",
	"genre_ids": [878],
	"backdrop_path": "\/VuukZLgaCrho2Ar8Scl9HtV3yD.jpg",
	"adult": false,
	"overview": "When Eddie Brock acquires the powers of a symbiote, he will have to release his alter-ego \"Venom\" to save his life.",
	"release_date": "2018-10-03"*/

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getVote_average() {
        return vote_average;
    }

    public void setVote_average(float vote_average) {
        this.vote_average = vote_average;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPoster_path() {
        return poster_path;
    }

    public void setPoster_path(String poster_path) {
        this.poster_path = poster_path;
    }

    public String getOriginal_language() {
        return original_language;
    }

    public void setOriginal_language(String original_language) {
        this.original_language = original_language;
    }

    public String getBackdrop_path() {
        return backdrop_path;
    }

    public void setBackdrop_path(String backdrop_path) {
        this.backdrop_path = backdrop_path;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getThumbnail() {
        return Thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        Thumbnail = thumbnail;
    }

}
