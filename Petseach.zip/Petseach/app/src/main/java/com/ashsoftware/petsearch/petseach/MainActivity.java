package com.ashsoftware.petsearch.petseach;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.ashsoftware.petsearch.petseach.utils.ApiConfig;
import com.ashsoftware.petsearch.petseach.utils.App;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class MainActivity extends AppCompatActivity {
    RecyclerView recycler_view;
    MyAdapter mAdapter;
    List<MDMovie> myDataset = new ArrayList<>();
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recycler_view = (RecyclerView) findViewById(R.id.recycler_view);
        toolbar=(Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recycler_view.setLayoutManager(mLayoutManager);
        recycler_view.setItemAnimator(new DefaultItemAnimator());
        recycler_view.setAdapter(mAdapter);
        // specify an adapter (see also next example)
        mAdapter = new MyAdapter(myDataset,this);
        recycler_view.setAdapter(mAdapter);
        getmovieList();
    }

    private void getmovieList() {

        StringRequest strReq = new StringRequest(Request.Method.GET,
                ApiConfig.Discover, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {

               try {

                    JSONObject jObj = new JSONObject(response);
                   JSONArray jsonArray = jObj.getJSONArray("results");
                   Gson gson = new Gson();
                   myDataset.clear();
                   for (int i=0;i<jsonArray.length();i++){
                       MDMovie movie = gson.fromJson(jsonArray.get(i).toString(),MDMovie.class);
                       myDataset.add(movie);
                   }

                   mAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();

                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


            }
        });

        strReq.setShouldCache(false);
        App.getInstance().addToRequestQueue(strReq);
        strReq.setRetryPolicy(new DefaultRetryPolicy(
                500000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu); //your file name
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId()==android.R.id.home){
            finish();
        }
        return true;

    }

    @Override
    protected void onResume() {
        super.onResume();
        setTitle("Popular Movies");
    }
}
