package com.ashsoftware.petsearch.petseach.utils;

public class ApiConfig {

    public static String Discover = "https://api.themoviedb.org/3/discover/movie?api_key=b4673fcad5b2f86b8ef99965d810ec5d&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1";
    public static final String BASE_URL = "http://api.themoviedb.org/3";
    public static final String IMAG_URI="http://image.tmdb.org/t/p/w185/";
    public static final String IMAG_ORIGINAL = "http://image.tmdb.org/t/p/original/";
    public static final String API_KEY_LNG = "?api_key=b4673fcad5b2f86b8ef99965d810ec5d&language=en-US";
    public static final String MOVIE_DETAILS =  "https://api.themoviedb.org/3/movie/";

}
